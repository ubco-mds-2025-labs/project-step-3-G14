"""
Alerts sub-package.

Includes:
- Expiry alerts
- Low-stock alerts
"""
