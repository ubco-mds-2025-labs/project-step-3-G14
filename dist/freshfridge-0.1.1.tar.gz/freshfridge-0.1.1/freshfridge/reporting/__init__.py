"""
Reporting sub-package.

Includes:
- Base report class
- Inventory summary report
- Shopping list report
"""
