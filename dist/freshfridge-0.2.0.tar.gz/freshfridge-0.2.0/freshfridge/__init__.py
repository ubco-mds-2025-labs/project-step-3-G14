"""
FreshFridge package initialization.

This package provides tools for:
- Refrigerator inventory management
- Expiry alerts
- Low-stock alerts
- Reporting and shopping list generation
"""
